
 GoEuro Test -This application is developed using below
========================================================
JDK         :  1.7.0
IDE         :  Intellij 14.1.4
Build Tool  :  Maven 3.2.3

Jar file location : \GoEuro_JavaTest\out\artifacts\GoEuroTest_jar\GoEuroTest.jar

CSV file will be generated under given city which will be got created user directory

java -jar GoEuroTest.jar Mumbai

ex: If the given city is 'Mumbai' then the CSV file will be generated under folder name 'Mumbai' inside the user directory.

C:\Users\Satyaban\Mumbai\Mumbai_2015-09-12.csv

