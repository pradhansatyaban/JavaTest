package test.com.mediaocenJavaTest.mediaocenHttpClient;

import com.mediaocenTest.mediaocenHttpClient.MoClient;
import com.mediaocenJavaTest.mediaocenProduct.MoClientTest;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.fail;


/**
 * MoClient Tester.
 *
 *
 * @author Satyaban Pradhan
 * @version 1.0
 * @since Oct 11, 2016
 */
 */
public class MoClientTest {

    @Before
    public void before() throws Exception {
    }

    @After
    public void after() throws Exception {
    }

    /**
     * Method: getProduct(final StringBuilder city)
     */
    @Test
    public void testGetProduct() throws Exception {
         MoClientTest e0Obj = new  MoClientTest();
        try {
            Product[] e0 = e0Obj.getProduct(null);
        } catch (Exception e) {
            fail();
        }
    }


    /**
     * Method: convert(final String response)
     */
    @Test
    public void testConvert() throws Exception {
//TODO: Test goes here... 

    }

    /**
     * Method: buildURL(final String city)
     */
    @Test
    public void testBuildURL() throws Exception {
//TODO: Test goes here... 
/* 

*/
    }


    @Test

    public void testSequence() {

        BillingClient e0Obj = new BillingClient();

        StringBuilder e0Arg0 = new StringBuilder(null);

        try {

            Product[] e0 = e0Obj.getProduct(e0Arg0);

        } catch (Exception e) {

            fail();

        }


        StringBuilder e1Arg0 = new StringBuilder(null);
        try {
            Product[] e1 = e0Obj.getProduct(e1Arg0);
        } catch (Exception e) {

            fail();

        }

        StringBuilder e2Arg0 = new StringBuilder(-51);

        try {

            Product[] e2 = e0Obj.getProduct(e2Arg0);

        } catch (Exception e) {

            fail();

        }

        StringBuilder e3Arg0 = new StringBuilder(54);

        try {

            Product[] e3 = e0Obj.getProduct(e3Arg0);

        } catch (Exception e) {

            fail();

        }

        StringBuilder e4Arg0 = new StringBuilder(null);

        try {

            Product[] e4 = e0Obj.getProduct(e4Arg0);

        } catch (Exception e) {

            fail();

        }

        StringBuilder e5Arg0 = new StringBuilder("(Y");

        try {

            Product[] e5 = e0Obj.getProduct(e5Arg0);

        } catch (Exception e) {

            fail();

        }

        StringBuilder e6Arg0 = new StringBuilder();

        try {

            Product[] e6 = e0Obj.getProduct(e6Arg0);

        } catch (Exception e) {

            fail();

        }

        StringBuilder e7Arg0 = new StringBuilder();

        e7Arg0.lastIndexOf("Xi,EJ", -1);

        e7Arg0.append(false);

        e7Arg0.insert(86, 'j');

        char[] e7Arg03Arg0 = new char[18];

        e7Arg03Arg0[0] = '1';

        e7Arg03Arg0[1] = '6';

        e7Arg03Arg0[2] = 'b';

        e7Arg03Arg0[3] = 'j';

        e7Arg03Arg0[4] = '1';

        e7Arg03Arg0[5] = 'z';

        e7Arg03Arg0[6] = 'F';

        e7Arg03Arg0[7] = 'f';

        e7Arg03Arg0[8] = ';';

        e7Arg03Arg0[9] = 'T';

        e7Arg03Arg0[10] = 'Z';

        e7Arg03Arg0[11] = 'p';

        e7Arg03Arg0[12] = 'r';

        e7Arg03Arg0[13] = '<';

        e7Arg03Arg0[14] = '&';

        e7Arg03Arg0[15] = 'J';

        e7Arg03Arg0[16] = 'd';

        e7Arg03Arg0[17] = 'J';

        e7Arg0.append(e7Arg03Arg0);

        try {

            Product[] e7 = e0Obj.getProduct(e7Arg0);

        } catch (Exception e) {

            fail();

        }

        StringBuilder e8Arg0 = new StringBuilder();

        try {

            Product[] e8 = e0Obj.getProduct(e8Arg0);

        } catch (Exception e) {

            fail();

        }

        StringBuilder e9Arg0 = new StringBuilder(-78);

        try {

            Product[] e9 = e0Obj.getProduct(e9Arg0);

        } catch (Exception e) {

            fail();

        }
    }


} 
