package com.mediaoceanJavaTest.mediaOcean;

import com.mediaoceanJavaTest.mediaoceanException.CsvWriterException;
import com.mediaoceanJavaTest.mediaoceanException.HttpResponseException;
import com.mediaoceanJavaTest.mediaoceanHttpClient.MoClient;
import com.mediaoceanJavaTest.mediaoceanProduct.Product;
import com.mediaoceanJavaTest.mediaoceanCSVWriter.CsvWriter;


/*
 * Created by Satyaban Pradhan
 *              on 28/09/2016
 */

public class mediaOcean {

    public static void main(String[] args) throws HttpResponseException, CsvWriterException {
        if (args.length == 0) {
            System.err.println("Please enter Location!");
            printUsage();
        } else {
            StringBuilder inputCity = new StringBuilder();
            System.out.println("Note : \n" +
                    "1. Resultant CSV file will get created in your users directory present in C drive.Like:C:\\Users\\sony\\yourCsvFileName.\n"+
                    "2. Resultant CSV file get generateBill  with name Location you provided and Date and Time. Like If you provide location as Product Catalog so\n"+
                    "   file will have name :-Bill_201503221206.csv");
            inputCity.append(args[0]);
            for (int i = 1; i < args.length; i++) {
                inputCity.append(" " + args[i]);
            }
            Position[] response = new MOClient().getProduct(inputProduct);
            //System.out.println("Response---------------"+response);
            CsvWriter.writeToCsv(response, inputCity);
        }
    }

    private static void printUsage() {
        System.err.println("Usage: Please enter  name");
        System.exit(1);
    }
}
