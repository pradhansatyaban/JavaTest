package com.mediaoceanJavaTest.mediaoceanoHttpClient;

import com.mediaoceanJavaTest.mediaoceanAppUtil.MOReadProperties;
import com.mediaoceanJavaTest.mediaoceanProduct.Product;
import com.mediaoceanJavaTest.mediaoceanException.HttpResponseException;
import com.google.gson.Gson;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

import static java.lang.String.format;


/*
 * Created by Satyaban Pradhan
 *              on 28/08/2015
 */

public class MoClient {
    private static final Logger logger = LoggerFactory.getLogger(GoEuroClient.class);

    public Product[] getProduct(final StringBuilder location) throws HttpResponseException {
        if (StringUtils.isEmpty(location) || StringUtils.isBlank(location)) {
            throw new IllegalArgumentException("The location is empty or blank!");
        }
        String cleanLocation = location.toString().trim().replace(" ", "%20");  //added for location (string having spaces in between location
        final HttpClient client = new HttpClient();
        final String url = (cleanLocation);

        final HttpMethod method = new GetMethod(url);

        try {
            int status = client.executeMethod(method);
            if (status != HttpStatus.SC_OK) {
                final String msg = "An error occurred while executing GET to RESTFull API: %s";
                throw new HttpResponseException(format(msg, url), status);
            }
            final String response = method.getResponseBodyAsString();
            Product[] data = convert(response);
            return data;
        } catch (HttpException e) {
            logger.error("HttpException: {}", e.getMessage());
            throw new HttpResponseException(e.getMessage());
        } catch (IOException e) {
            logger.error("An IO mediaoceanException was thrown with message: {}", e.getMessage());
            throw new HttpResponseException(e.getMessage());
        } finally {
            method.releaseConnection();
        }
    }

    private Product[] convert(final String response) {
        final Gson gson = new Gson();
        return gson.fromJson(response, Product[].class);
    }

    private String (final String location) {
        StringBuilder stringBuilder = new StringBuilder(MoReadProperties.getURL());
        stringBuilder.append(location);
        return stringBuilder.toString();
    }
}
